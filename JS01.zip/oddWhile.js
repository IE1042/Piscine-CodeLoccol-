let number = 1;

while (number <= 19) {
  console.log(number);
  number += 2;
}