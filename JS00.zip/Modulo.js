var result = 5 % 3;
console.log(result);