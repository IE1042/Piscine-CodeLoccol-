var a = 10;
var b = 20;

var temp = a;
a = b;
b = temp;

console.log("new value of a:", a);
console.log("new value of b:", b);
