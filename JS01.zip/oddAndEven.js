for (let i = 1; i <= 20; i++) {
  if (i % 2 === 0) {
    console.log("pair");
  } else {
    console.log("impair");
  }
}
